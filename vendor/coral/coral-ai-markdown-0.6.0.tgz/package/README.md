# @coral-ai/markdown

`CoralMarkdown` — a themed Markdown renderer for Coral with GFM, syntax highlighting, and prop-driven font controls.

## Install

```sh
npm install @coral-ai/markdown @coral-ai/bundleicons @fluentui/react-components react react-dom
```

Peer dependencies do not install transitively. Install all of the above explicitly.

## Usage

```tsx
import { CoralMarkdown } from "@coral-ai/markdown";
import "@coral-ai/markdown/styles";

<CoralMarkdown>{`# Hello\n\nSome **markdown** content.`}</CoralMarkdown>
```

See [coral-ai](https://github.com/mochimilk/coral-ai) for the full project.

## Typography in 0.6

Shared markdown paragraphs use unitless line-height `1.55`; lists use `1.5`. These rules apply at small (14px), default (15px), and large (18px) body sizes, including chat and documentation. Heading hierarchy is unchanged.
