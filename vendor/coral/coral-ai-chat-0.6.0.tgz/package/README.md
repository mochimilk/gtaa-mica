# @coral-ai/chat

Chat surface for Coral: `<Chat>`, `<Chat.Canvas>`, `<Chat.Messages>`, `<Chat.Input>`, streaming helpers, and a model-agnostic agent tool-use runner.

## Install

```sh
npm install @coral-ai/chat @coral-ai/markdown @coral-ai/bundleicons @fluentui/react-components @fluentui/react-icons react react-dom
```

Peer dependencies do not install transitively. Install all of the above explicitly.

## Usage

```tsx
import { Chat } from "@coral-ai/chat";

<Chat onSendMessage={async (input) => `You said: ${input}`} />
```

`onSendMessage` is the one handler — return a string, an async iterable of
`ChatChunk`s, or a `ChatResponse`. A backend URL can also be supplied via the
`api` prop or `coral.config.json`'s `chat.api`.

`disclaimer?: React.ReactNode` adds optional content beneath the input. By
default no disclaimer or footer space is rendered; `undefined`, `null`, and
`false` also hide it. To retain the previous built-in text, opt in explicitly:

```tsx
<Chat api="/api/chat" disclaimer="AI makes mistakes. Check outputs." />
```

Custom React content, such as a policy link, is also supported.

See [coral-ai](https://github.com/mochimilk/coral-ai) for the full project.

## Migrating to 0.6

User-message editing and `useChatContext().editMessage` have been removed. Assistant Copy/Regenerate and error Retry remain. The disclaimer is opt-in: pass `disclaimer` to render footer content; omission reserves no space. Sidecars use the true default 15px assistant font. Message rows use a 0px gap; footer buttons are small with a 2px gap.
