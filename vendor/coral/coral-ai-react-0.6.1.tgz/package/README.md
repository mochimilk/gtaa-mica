# @coral-ai/react

Base layer of Coral: provider, theme, layout primitives, panels, navbar, and content shell, built on top of Fluent UI.

## Install

```sh
npm install @coral-ai/react @coral-ai/bundleicons @fluentui/react-components react react-dom
```

Peer dependencies do not install transitively. Install all of the above explicitly.

## Usage

```tsx
import {
  CoralProvider,
  CoralShellRow,
  Navbar,
  Panel,
  Content,
} from "@coral-ai/react";

export default function App() {
  return (
    <CoralProvider>
      <CoralShellRow>
        <Navbar />
        <Panel.Left />
        <Content>Hello Coral</Content>
      </CoralShellRow>
    </CoralProvider>
  );
}
```

See [coral-ai](https://github.com/mochimilk/coral-ai) for the full project and docs.

## Migrating to 0.6

Mounting `Panel.Left` automatically supplies an accessible Navbar toggle. An ID is generated if `panelID` is omitted; `defaultOpen={false}` now works in that case. An explicitly mounted `Panel.Toggle` with the same ID suppresses the automatic control. Panel registration is cleaned up on unmount. Left/right resize drags temporarily disable text selection and restore it on release, cancellation or unmount.


## Right panels and Navbar in 0.6.1

Mounting `Panel.Right` now adds its control after custom `Navbar.actionsEnd` content. No explicit ID or toggle is needed. Put `icon` and an accessible `label` on the panel. A single right panel may omit its icon; when multiple right panels are mounted, every panel requires one. Missing icons produce development console errors.

Manual toggles remain supported and suppress their automatic counterpart. Panel-owned icons take precedence over legacy toggle icons. Mount/unmount, StrictMode effect replay, and icon updates preserve correct registration and selection. Navbar end actions have zero gap between buttons, and bundled logo icons show regular by default and filled on hover.
