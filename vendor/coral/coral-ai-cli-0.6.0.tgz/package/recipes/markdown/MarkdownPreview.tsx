import { CoralMarkdown } from "@coral-ai/markdown";

export interface MarkdownPreviewProps {
  content: string;
}

export default function MarkdownPreview({ content }: MarkdownPreviewProps) {
  return <CoralMarkdown content={content} />;
}
