import { Chat, type ChatChunk } from "@coral-ai/chat";

// Replace echoAgent with a real handler — return a string,
// AsyncIterable<ChatChunk>, or Promise of either.
async function* echoAgent(input: string): AsyncIterable<ChatChunk> {
  const reply = `You said: **${input}**\n\nWire this up in components/PanelChat.tsx.`;
  for (const word of reply.split(/(\s+)/)) {
    await new Promise((r) => setTimeout(r, 18));
    yield word;
  }
}

export default function PanelChat() {
  return (
    <Chat
      onSendMessage={(input) => echoAgent(input)}
      welcomeMessage={
        <div style={{ textAlign: "center", padding: 16 }}>
          <h3 style={{ margin: "8px 0" }}>How can I help?</h3>
          <p style={{ marginTop: 0, opacity: 0.7 }}>
            Ask anything — this is a stub agent for now.
          </p>
        </div>
      }
    />
  );
}
