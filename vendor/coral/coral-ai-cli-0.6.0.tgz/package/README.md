# @coral-ai/cli

Post-scaffold CLI for Coral. Adds curated component recipes (chat, markdown, etc.) to an existing project.

To **scaffold** a new project, use [`@coral-ai/create`](../create) via `npm create @coral-ai`. This package is the day-to-day CLI you reach for *after* the project exists.

## Usage

Scaffolded projects ship `@coral-ai/cli` as a devDependency, so the `coral` bin is available locally:

```sh
pnpm coral add chat
pnpm coral add markdown
```

You can also invoke it standalone:

```sh
npx @coral-ai/cli add chat
```

## `add`

Adds a curated recipe (npm packages + snippet files) to an existing project.

```sh
coral add <recipe> [--dest <dir>] [--pm <npm|pnpm|yarn|bun>] [--overwrite] [--no-install]
```

Recipes shipped with this version:

| Recipe     | What it adds                                                        |
| ---------- | ------------------------------------------------------------------- |
| `chat`     | `@coral-ai/chat` + `@coral-ai/markdown` + a `PanelChat.tsx` snippet |
| `markdown` | `@coral-ai/markdown` + a `MarkdownPreview.tsx` snippet              |

Recipes assume your app already wraps `<App />` in `<CoralProvider>`. The CLI prints a wire-up snippet after install when needed.

## License

MIT — see [LICENSE](./LICENSE).
