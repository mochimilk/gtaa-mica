# @coral-ai/charts

Chart primitives for Coral.

> **Status:** placeholder. This package is reserved under the `@coral-ai` scope; chart components will land in a future release.

See [coral-ai](https://github.com/mochimilk/coral-ai) for the full project.

## License

MIT
